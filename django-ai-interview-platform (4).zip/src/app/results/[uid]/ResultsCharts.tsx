"use client";

import { useEffect, useRef } from "react";

interface QuestionResult {
  title: string;
  difficulty: string;
  attempted: boolean;
  verdict: string;
  passed: number;
  total: number;
}

interface WebcamEvent {
  timestamp: number;
  type: string;
  message: string;
  severity: string;
}

interface ResultsChartsProps {
  questionResults: QuestionResult[];
  postureScore: number;
  gazeScore: number;
  totalWarnings: number;
  passRate: number;
  webcamEvents: WebcamEvent[];
}

export default function ResultsCharts({
  questionResults,
  postureScore,
  gazeScore,
  totalWarnings,
  passRate,
  webcamEvents,
}: ResultsChartsProps) {
  const doughnutRef = useRef<HTMLCanvasElement>(null);
  const radarRef = useRef<HTMLCanvasElement>(null);
  const lineRef = useRef<HTMLCanvasElement>(null);
  const barRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    // Coding Performance Doughnut
    if (doughnutRef.current) {
      drawDoughnut(doughnutRef.current, questionResults);
    }

    // Behavioral Radar
    if (radarRef.current) {
      drawRadar(radarRef.current, postureScore, gazeScore, totalWarnings);
    }

    // Warnings Timeline
    if (lineRef.current) {
      drawTimeline(lineRef.current, webcamEvents);
    }

    // Per-question bar chart
    if (barRef.current) {
      drawBarChart(barRef.current, questionResults);
    }
  }, [questionResults, postureScore, gazeScore, totalWarnings, webcamEvents, passRate]);

  return (
    <>
      {/* Coding Performance Doughnut */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6">
        <h3 className="text-lg font-bold mb-4">Coding Performance</h3>
        <div className="flex items-center justify-center">
          <canvas ref={doughnutRef} width={250} height={250} />
        </div>
      </div>

      {/* Behavioral Radar */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6">
        <h3 className="text-lg font-bold mb-4">Behavioral Scores</h3>
        <div className="flex items-center justify-center">
          <canvas ref={radarRef} width={250} height={250} />
        </div>
      </div>

      {/* Per-question performance */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6">
        <h3 className="text-lg font-bold mb-4">Test Cases per Question</h3>
        <div className="flex items-center justify-center">
          <canvas ref={barRef} width={400} height={200} />
        </div>
      </div>

      {/* Warnings Timeline */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6">
        <h3 className="text-lg font-bold mb-4">Warnings Timeline</h3>
        <div className="flex items-center justify-center">
          <canvas ref={lineRef} width={400} height={200} />
        </div>
      </div>
    </>
  );
}

function drawDoughnut(
  canvas: HTMLCanvasElement,
  questionResults: QuestionResult[]
) {
  const ctx = canvas.getContext("2d");
  if (!ctx) return;

  const accepted = questionResults.filter(
    (q) => q.verdict === "Accepted"
  ).length;
  const wrongAnswer = questionResults.filter(
    (q) => q.attempted && q.verdict !== "Accepted"
  ).length;
  const notAttempted = questionResults.filter((q) => !q.attempted).length;

  const total = questionResults.length || 1;
  const data = [
    { value: accepted, color: "#10b981", label: "Accepted" },
    { value: wrongAnswer, color: "#ef4444", label: "Wrong Answer" },
    { value: notAttempted, color: "#475569", label: "Not Attempted" },
  ];

  const centerX = 125;
  const centerY = 125;
  const radius = 90;
  const innerRadius = 60;

  let startAngle = -Math.PI / 2;

  ctx.clearRect(0, 0, canvas.width, canvas.height);

  data.forEach((segment) => {
    const sliceAngle = (segment.value / total) * 2 * Math.PI;
    if (segment.value === 0) return;

    ctx.beginPath();
    ctx.arc(centerX, centerY, radius, startAngle, startAngle + sliceAngle);
    ctx.arc(
      centerX,
      centerY,
      innerRadius,
      startAngle + sliceAngle,
      startAngle,
      true
    );
    ctx.closePath();
    ctx.fillStyle = segment.color;
    ctx.fill();

    startAngle += sliceAngle;
  });

  // Center text
  ctx.fillStyle = "#e2e8f0";
  ctx.font = "bold 24px system-ui";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText(`${accepted}/${total}`, centerX, centerY - 8);
  ctx.fillStyle = "#94a3b8";
  ctx.font = "12px system-ui";
  ctx.fillText("Solved", centerX, centerY + 14);

  // Legend
  const legendY = 230;
  data.forEach((item, i) => {
    const x = 20 + i * 85;
    ctx.fillStyle = item.color;
    ctx.fillRect(x, legendY, 8, 8);
    ctx.fillStyle = "#94a3b8";
    ctx.font = "10px system-ui";
    ctx.textAlign = "left";
    ctx.fillText(`${item.label} (${item.value})`, x + 12, legendY + 8);
  });
}

function drawRadar(
  canvas: HTMLCanvasElement,
  postureScore: number,
  gazeScore: number,
  totalWarnings: number
) {
  const ctx = canvas.getContext("2d");
  if (!ctx) return;

  ctx.clearRect(0, 0, canvas.width, canvas.height);

  const centerX = 125;
  const centerY = 115;
  const maxRadius = 80;
  const categories = [
    { label: "Posture", value: postureScore },
    { label: "Eye Contact", value: gazeScore },
    { label: "Focus", value: Math.max(0, 100 - totalWarnings * 5) },
    { label: "Stillness", value: Math.max(0, 100 - totalWarnings * 3) },
    { label: "Confidence", value: Math.round((postureScore + gazeScore) / 2) },
  ];

  const numSides = categories.length;
  const angleStep = (2 * Math.PI) / numSides;

  // Draw grid
  for (let level = 1; level <= 4; level++) {
    const r = (maxRadius * level) / 4;
    ctx.beginPath();
    for (let i = 0; i <= numSides; i++) {
      const angle = i * angleStep - Math.PI / 2;
      const x = centerX + r * Math.cos(angle);
      const y = centerY + r * Math.sin(angle);
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.strokeStyle = "#334155";
    ctx.lineWidth = 1;
    ctx.stroke();
  }

  // Draw axes
  for (let i = 0; i < numSides; i++) {
    const angle = i * angleStep - Math.PI / 2;
    ctx.beginPath();
    ctx.moveTo(centerX, centerY);
    ctx.lineTo(
      centerX + maxRadius * Math.cos(angle),
      centerY + maxRadius * Math.sin(angle)
    );
    ctx.strokeStyle = "#334155";
    ctx.stroke();
  }

  // Draw data
  ctx.beginPath();
  categories.forEach((cat, i) => {
    const angle = i * angleStep - Math.PI / 2;
    const r = (cat.value / 100) * maxRadius;
    const x = centerX + r * Math.cos(angle);
    const y = centerY + r * Math.sin(angle);
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  });
  ctx.closePath();
  ctx.fillStyle = "rgba(139, 92, 246, 0.2)";
  ctx.fill();
  ctx.strokeStyle = "#8b5cf6";
  ctx.lineWidth = 2;
  ctx.stroke();

  // Data points
  categories.forEach((cat, i) => {
    const angle = i * angleStep - Math.PI / 2;
    const r = (cat.value / 100) * maxRadius;
    const x = centerX + r * Math.cos(angle);
    const y = centerY + r * Math.sin(angle);
    ctx.beginPath();
    ctx.arc(x, y, 3, 0, 2 * Math.PI);
    ctx.fillStyle = "#8b5cf6";
    ctx.fill();
  });

  // Labels
  ctx.fillStyle = "#94a3b8";
  ctx.font = "11px system-ui";
  ctx.textAlign = "center";
  categories.forEach((cat, i) => {
    const angle = i * angleStep - Math.PI / 2;
    const r = maxRadius + 18;
    const x = centerX + r * Math.cos(angle);
    const y = centerY + r * Math.sin(angle);
    ctx.fillText(cat.label, x, y + 4);
  });
}

function drawTimeline(canvas: HTMLCanvasElement, events: WebcamEvent[]) {
  const ctx = canvas.getContext("2d");
  if (!ctx) return;

  ctx.clearRect(0, 0, canvas.width, canvas.height);

  if (events.length === 0) {
    ctx.fillStyle = "#94a3b8";
    ctx.font = "14px system-ui";
    ctx.textAlign = "center";
    ctx.fillText("No webcam events recorded", 200, 100);
    return;
  }

  const padding = { top: 20, right: 30, bottom: 40, left: 40 };
  const width = canvas.width - padding.left - padding.right;
  const height = canvas.height - padding.top - padding.bottom;

  // Group events by minute
  const startTime = events[0].timestamp;
  const buckets: Record<number, number> = {};
  events.forEach((e) => {
    const minute = Math.floor((e.timestamp - startTime) / 60000);
    buckets[minute] = (buckets[minute] || 0) + 1;
  });

  const minutes = Object.keys(buckets).map(Number);
  const maxMinute = Math.max(...minutes, 1);
  const maxCount = Math.max(...Object.values(buckets), 1);

  // Draw axes
  ctx.strokeStyle = "#334155";
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(padding.left, padding.top);
  ctx.lineTo(padding.left, padding.top + height);
  ctx.lineTo(padding.left + width, padding.top + height);
  ctx.stroke();

  // Draw line
  ctx.beginPath();
  ctx.strokeStyle = "#f59e0b";
  ctx.lineWidth = 2;

  const points: Array<[number, number]> = [];
  for (let m = 0; m <= maxMinute; m++) {
    const x = padding.left + (m / maxMinute) * width;
    const y =
      padding.top + height - ((buckets[m] || 0) / maxCount) * height;
    points.push([x, y]);
    if (m === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  ctx.stroke();

  // Fill area
  ctx.beginPath();
  points.forEach(([x, y], i) => {
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  });
  ctx.lineTo(padding.left + width, padding.top + height);
  ctx.lineTo(padding.left, padding.top + height);
  ctx.closePath();
  ctx.fillStyle = "rgba(245, 158, 11, 0.1)";
  ctx.fill();

  // Draw dots
  points.forEach(([x, y]) => {
    ctx.beginPath();
    ctx.arc(x, y, 3, 0, 2 * Math.PI);
    ctx.fillStyle = "#f59e0b";
    ctx.fill();
  });

  // Labels
  ctx.fillStyle = "#94a3b8";
  ctx.font = "10px system-ui";
  ctx.textAlign = "center";
  ctx.fillText("Time (minutes)", padding.left + width / 2, canvas.height - 5);

  ctx.save();
  ctx.translate(12, padding.top + height / 2);
  ctx.rotate(-Math.PI / 2);
  ctx.fillText("Warnings", 0, 0);
  ctx.restore();
}

function drawBarChart(
  canvas: HTMLCanvasElement,
  questionResults: QuestionResult[]
) {
  const ctx = canvas.getContext("2d");
  if (!ctx) return;

  ctx.clearRect(0, 0, canvas.width, canvas.height);

  if (questionResults.length === 0) {
    ctx.fillStyle = "#94a3b8";
    ctx.font = "14px system-ui";
    ctx.textAlign = "center";
    ctx.fillText("No questions data", 200, 100);
    return;
  }

  const padding = { top: 20, right: 20, bottom: 40, left: 40 };
  const width = canvas.width - padding.left - padding.right;
  const height = canvas.height - padding.top - padding.bottom;

  const maxTests = Math.max(
    ...questionResults.map((q) => q.total),
    1
  );
  const barWidth = Math.min(
    40,
    width / questionResults.length / 2 - 5
  );
  const gap =
    (width - barWidth * 2 * questionResults.length) /
    (questionResults.length + 1);

  // Draw axes
  ctx.strokeStyle = "#334155";
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(padding.left, padding.top);
  ctx.lineTo(padding.left, padding.top + height);
  ctx.lineTo(padding.left + width, padding.top + height);
  ctx.stroke();

  questionResults.forEach((q, i) => {
    const x = padding.left + gap * (i + 1) + barWidth * 2 * i;

    // Total bar
    const totalHeight = (q.total / maxTests) * height;
    ctx.fillStyle = "#334155";
    ctx.fillRect(
      x,
      padding.top + height - totalHeight,
      barWidth,
      totalHeight
    );

    // Passed bar
    const passedHeight = (q.passed / maxTests) * height;
    ctx.fillStyle = q.verdict === "Accepted" ? "#10b981" : "#ef4444";
    ctx.fillRect(
      x + barWidth + 2,
      padding.top + height - passedHeight,
      barWidth,
      passedHeight
    );

    // Label
    ctx.fillStyle = "#94a3b8";
    ctx.font = "10px system-ui";
    ctx.textAlign = "center";
    ctx.fillText(
      `Q${i + 1}`,
      x + barWidth,
      padding.top + height + 15
    );
  });

  // Legend
  ctx.fillStyle = "#334155";
  ctx.fillRect(padding.left + width - 120, 5, 8, 8);
  ctx.fillStyle = "#94a3b8";
  ctx.font = "10px system-ui";
  ctx.textAlign = "left";
  ctx.fillText("Total", padding.left + width - 108, 13);

  ctx.fillStyle = "#10b981";
  ctx.fillRect(padding.left + width - 60, 5, 8, 8);
  ctx.fillStyle = "#94a3b8";
  ctx.fillText("Passed", padding.left + width - 48, 13);
}
