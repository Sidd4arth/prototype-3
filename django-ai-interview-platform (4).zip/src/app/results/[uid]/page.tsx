import { db } from "@/db";
import { sessions, questions, submissions, webcamLogs } from "@/db/schema";
import { eq, asc, and } from "drizzle-orm";
import { notFound } from "next/navigation";
import Link from "next/link";
import ResultsCharts from "./ResultsCharts";

export const dynamic = "force-dynamic";

interface PageProps {
  params: Promise<{ uid: string }>;
}

export default async function ResultsPage({ params }: PageProps) {
  const { uid } = await params;

  const [session] = await db
    .select()
    .from(sessions)
    .where(eq(sessions.uid, uid));

  if (!session) {
    notFound();
  }

  const sessionQuestions = await db
    .select()
    .from(questions)
    .where(eq(questions.sessionId, session.id))
    .orderBy(asc(questions.questionIndex));

  const sessionSubmissions = await db
    .select()
    .from(submissions)
    .where(
      and(
        eq(submissions.sessionId, session.id),
        eq(submissions.submissionType, "submit")
      )
    )
    .orderBy(asc(submissions.createdAt));

  const sessionWebcamLogs = await db
    .select()
    .from(webcamLogs)
    .where(eq(webcamLogs.sessionId, session.id));

  // Calculate stats
  const questionsAttempted = new Set(
    sessionSubmissions.map((s) => s.questionId)
  ).size;
  const totalPassedTests = sessionSubmissions.reduce(
    (acc, s) => acc + (s.totalPassed || 0),
    0
  );
  const totalTests = sessionSubmissions.reduce(
    (acc, s) => acc + (s.totalTests || 0),
    0
  );
  const acceptedCount = sessionSubmissions.filter(
    (s) => s.verdict === "Accepted"
  ).length;

  const postureScore =
    sessionWebcamLogs.length > 0
      ? sessionWebcamLogs[0].postureScore ?? 85
      : 85;
  const gazeScore =
    sessionWebcamLogs.length > 0
      ? sessionWebcamLogs[0].gazeScore ?? 80
      : 80;
  const totalWarnings =
    sessionWebcamLogs.length > 0
      ? sessionWebcamLogs[0].totalWarnings ?? 0
      : 0;

  const webcamEvents = sessionWebcamLogs.length > 0
    ? (sessionWebcamLogs[0].events as Array<{
        timestamp: number;
        type: string;
        message: string;
        severity: string;
      }>)
    : [];

  // Per-question results
  const questionResults = sessionQuestions.map((q) => {
    const qSubmissions = sessionSubmissions.filter(
      (s) => s.questionId === q.id
    );
    const lastSubmission = qSubmissions[qSubmissions.length - 1];
    return {
      title: q.title,
      difficulty: q.difficulty,
      attempted: qSubmissions.length > 0,
      verdict: lastSubmission?.verdict || "Not Attempted",
      passed: lastSubmission?.totalPassed || 0,
      total: lastSubmission?.totalTests || 0,
    };
  });

  const passRate = totalTests > 0 ? Math.round((totalPassedTests / totalTests) * 100) : 0;

  return (
    <div className="min-h-screen">
      {/* Navigation */}
      <nav className="border-b border-slate-800 bg-slate-950/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center font-bold text-sm">
              M
            </div>
            <span className="text-xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
              MockPrep
            </span>
          </Link>
          <Link
            href="/new-session"
            className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 rounded-lg font-medium transition-colors"
          >
            New Interview
          </Link>
        </div>
      </nav>

      <div className="max-w-6xl mx-auto px-6 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-2 text-sm text-slate-400 mb-2">
            <Link href="/" className="hover:text-white transition-colors">
              Home
            </Link>
            <span>/</span>
            <span>Results</span>
          </div>
          <h1 className="text-3xl font-bold mb-2">Interview Results</h1>
          <p className="text-slate-400">
            {session.companyName} — {session.role} • {session.lpa} LPA •{" "}
            {session.duration} min
          </p>
          {session.completedAt && (
            <p className="text-slate-500 text-sm mt-1">
              Completed {new Date(session.completedAt).toLocaleString()}
            </p>
          )}
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <StatCard
            label="Questions Attempted"
            value={`${questionsAttempted}/${sessionQuestions.length}`}
            color="blue"
          />
          <StatCard
            label="Test Cases Passed"
            value={`${totalPassedTests}/${totalTests}`}
            color="purple"
          />
          <StatCard
            label="Pass Rate"
            value={`${passRate}%`}
            color={passRate >= 70 ? "green" : passRate >= 40 ? "yellow" : "red"}
          />
          <StatCard
            label="Accepted Solutions"
            value={`${acceptedCount}`}
            color="green"
          />
        </div>

        {/* Charts */}
        <div className="grid md:grid-cols-2 gap-6 mb-8">
          <ResultsCharts
            questionResults={questionResults}
            postureScore={postureScore}
            gazeScore={gazeScore}
            totalWarnings={totalWarnings}
            passRate={passRate}
            webcamEvents={webcamEvents}
          />
        </div>

        {/* Question Breakdown */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 mb-8">
          <h2 className="text-xl font-bold mb-4">Question Breakdown</h2>
          <div className="space-y-3">
            {questionResults.map((q, i) => (
              <div
                key={i}
                className="flex items-center justify-between bg-slate-800/50 rounded-xl p-4"
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-8 h-8 rounded-lg flex items-center justify-center text-sm font-bold ${
                      q.verdict === "Accepted"
                        ? "bg-emerald-500/20 text-emerald-400"
                        : q.attempted
                        ? "bg-red-500/20 text-red-400"
                        : "bg-slate-700/50 text-slate-500"
                    }`}
                  >
                    {q.verdict === "Accepted"
                      ? "✓"
                      : q.attempted
                      ? "✗"
                      : "—"}
                  </div>
                  <div>
                    <h3 className="font-medium">{q.title}</h3>
                    <span
                      className={`text-xs ${
                        q.difficulty === "Easy"
                          ? "text-emerald-400"
                          : q.difficulty === "Medium"
                          ? "text-amber-400"
                          : "text-red-400"
                      }`}
                    >
                      {q.difficulty}
                    </span>
                  </div>
                </div>
                <div className="text-right">
                  <div
                    className={`font-medium ${
                      q.verdict === "Accepted"
                        ? "text-emerald-400"
                        : q.attempted
                        ? "text-red-400"
                        : "text-slate-500"
                    }`}
                  >
                    {q.verdict}
                  </div>
                  <div className="text-xs text-slate-500">
                    {q.attempted
                      ? `${q.passed}/${q.total} test cases`
                      : "Not attempted"}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Behavioral Analysis */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 mb-8">
          <h2 className="text-xl font-bold mb-4">Behavioral Analysis</h2>
          <div className="grid grid-cols-3 gap-4 mb-4">
            <div className="bg-slate-800/50 rounded-xl p-4 text-center">
              <div className="text-2xl font-bold text-blue-400">
                {postureScore}%
              </div>
              <div className="text-sm text-slate-400 mt-1">Posture Score</div>
            </div>
            <div className="bg-slate-800/50 rounded-xl p-4 text-center">
              <div className="text-2xl font-bold text-purple-400">
                {gazeScore}%
              </div>
              <div className="text-sm text-slate-400 mt-1">Gaze Score</div>
            </div>
            <div className="bg-slate-800/50 rounded-xl p-4 text-center">
              <div className="text-2xl font-bold text-amber-400">
                {totalWarnings}
              </div>
              <div className="text-sm text-slate-400 mt-1">Total Warnings</div>
            </div>
          </div>
        </div>

        {/* AI Feedback */}
        {session.aiFeedback && (
          <div className="bg-gradient-to-br from-blue-500/10 to-purple-500/10 border border-blue-500/20 rounded-2xl p-6 mb-8">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-sm">
                🤖
              </div>
              <h2 className="text-xl font-bold">AI Feedback</h2>
            </div>
            <div className="prose prose-invert prose-sm max-w-none">
              {session.aiFeedback.split("\n").map((line, i) => {
                if (line.startsWith("## ")) {
                  return (
                    <h2 key={i} className="text-lg font-bold mt-4 mb-2">
                      {line.replace("## ", "")}
                    </h2>
                  );
                }
                if (line.startsWith("### ")) {
                  return (
                    <h3
                      key={i}
                      className="text-md font-semibold mt-3 mb-1 text-blue-400"
                    >
                      {line.replace("### ", "")}
                    </h3>
                  );
                }
                if (line.startsWith("*")) {
                  return (
                    <p key={i} className="text-slate-500 text-xs italic mt-4">
                      {line.replace(/\*/g, "")}
                    </p>
                  );
                }
                return (
                  <p key={i} className="text-slate-300 leading-relaxed">
                    {line}
                  </p>
                );
              })}
            </div>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex gap-4 justify-center py-8">
          <Link
            href="/new-session"
            className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8 py-3 rounded-xl font-semibold transition-all"
          >
            Start New Interview
          </Link>
          <Link
            href="/"
            className="bg-slate-800 hover:bg-slate-700 text-white px-8 py-3 rounded-xl font-semibold transition-colors"
          >
            Back to Home
          </Link>
        </div>
      </div>
    </div>
  );
}

function StatCard({
  label,
  value,
  color,
}: {
  label: string;
  value: string;
  color: string;
}) {
  const colors: Record<string, string> = {
    blue: "from-blue-500/10 to-blue-500/5 border-blue-500/20",
    purple: "from-purple-500/10 to-purple-500/5 border-purple-500/20",
    green: "from-emerald-500/10 to-emerald-500/5 border-emerald-500/20",
    yellow: "from-amber-500/10 to-amber-500/5 border-amber-500/20",
    red: "from-red-500/10 to-red-500/5 border-red-500/20",
  };

  const textColors: Record<string, string> = {
    blue: "text-blue-400",
    purple: "text-purple-400",
    green: "text-emerald-400",
    yellow: "text-amber-400",
    red: "text-red-400",
  };

  return (
    <div
      className={`bg-gradient-to-br ${colors[color]} border rounded-xl p-4`}
    >
      <div className={`text-2xl font-bold ${textColors[color]}`}>{value}</div>
      <div className="text-sm text-slate-400 mt-1">{label}</div>
    </div>
  );
}
