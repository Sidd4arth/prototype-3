"use client";

import { useState, useEffect, useRef } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";

const durations = [
  { value: 30, label: "30 min", desc: "Quick practice (3 questions)" },
  { value: 45, label: "45 min", desc: "Standard (4 questions)" },
  { value: 60, label: "60 min", desc: "Full interview (4 questions)" },
  { value: 90, label: "90 min", desc: "Extended (5 questions)" },
];

export default function NewSessionPage() {
  const router = useRouter();
  const [companyName, setCompanyName] = useState("");
  const [role, setRole] = useState("");
  const [duration, setDuration] = useState(45);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");
  
  // Company autocomplete
  const [companies, setCompanies] = useState<string[]>([]);
  const [filteredCompanies, setFilteredCompanies] = useState<string[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [loadingCompanies, setLoadingCompanies] = useState(true);
  const inputRef = useRef<HTMLInputElement>(null);

  // Fetch companies on mount
  useEffect(() => {
    async function fetchCompanies() {
      try {
        const res = await fetch("/api/companies");
        const data = await res.json();
        setCompanies(data.companies || []);
      } catch {
        console.error("Failed to fetch companies");
      } finally {
        setLoadingCompanies(false);
      }
    }
    fetchCompanies();
  }, []);

  // Filter companies based on input
  useEffect(() => {
    if (companyName.trim().length === 0) {
      setFilteredCompanies(companies.slice(0, 15));
    } else {
      const search = companyName.toLowerCase();
      const filtered = companies
        .filter((c) => c.toLowerCase().includes(search))
        .slice(0, 10);
      setFilteredCompanies(filtered);
    }
  }, [companyName, companies]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (!companyName || !role) {
      setError("Please fill in all fields");
      return;
    }

    setIsLoading(true);

    try {
      const res = await fetch("/api/sessions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ companyName, role, lpa: "15", duration }),
      });

      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || "Failed to create session");
      }

      const data = await res.json();
      router.push(`/interview/${data.uid}`);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setIsLoading(false);
    }
  };

  const selectCompany = (company: string) => {
    setCompanyName(company);
    setShowSuggestions(false);
    inputRef.current?.blur();
  };

  return (
    <div className="min-h-screen">
      {/* Navigation */}
      <nav className="border-b border-slate-800 bg-slate-950/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center gap-3">
          <Link href="/" className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center font-bold text-sm">
              M
            </div>
            <span className="text-xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
              MockPrep
            </span>
          </Link>
        </div>
      </nav>

      <div className="max-w-2xl mx-auto px-6 py-12">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Configure Your Mock Interview</h1>
          <p className="text-slate-400">
            Questions are fetched from real interview databases based on your target company.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Company Name with Autocomplete */}
          <div className="relative">
            <label className="block text-sm font-medium mb-2">
              Target Company
              {loadingCompanies && (
                <span className="ml-2 text-xs text-slate-500">Loading companies...</span>
              )}
            </label>
            <input
              ref={inputRef}
              type="text"
              value={companyName}
              onChange={(e) => {
                setCompanyName(e.target.value);
                setShowSuggestions(true);
              }}
              onFocus={() => setShowSuggestions(true)}
              onBlur={() => setTimeout(() => setShowSuggestions(false), 200)}
              className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-colors"
              placeholder="e.g., Google, Amazon, Microsoft..."
              autoComplete="off"
            />

            {/* Autocomplete dropdown */}
            {showSuggestions && filteredCompanies.length > 0 && (
              <div className="absolute z-20 w-full mt-1 bg-slate-800 border border-slate-700 rounded-xl shadow-xl max-h-64 overflow-y-auto">
                {filteredCompanies.map((company) => (
                  <button
                    key={company}
                    type="button"
                    onClick={() => selectCompany(company)}
                    className={`w-full px-4 py-2.5 text-left text-sm hover:bg-slate-700 transition-colors flex items-center justify-between ${
                      company.toLowerCase() === companyName.toLowerCase()
                        ? "bg-blue-600/20 text-blue-400"
                        : "text-slate-300"
                    }`}
                  >
                    <span>{company}</span>
                    {company.toLowerCase() === companyName.toLowerCase() && (
                      <span className="text-xs text-emerald-400">✓ Selected</span>
                    )}
                  </button>
                ))}
              </div>
            )}

            {/* Popular companies quick select */}
            <div className="flex flex-wrap gap-2 mt-3">
              {["Google", "Amazon", "Microsoft", "Meta", "Apple", "Netflix", "Adobe", "Goldman Sachs", "Uber", "Flipkart"].map((company) => (
                <button
                  key={company}
                  type="button"
                  onClick={() => selectCompany(company)}
                  className={`px-3 py-1 rounded-lg text-xs font-medium transition-colors ${
                    companyName === company
                      ? "bg-blue-600 text-white"
                      : companies.includes(company)
                        ? "bg-slate-800 text-slate-300 hover:bg-slate-700 border border-slate-700"
                        : "bg-slate-800 text-slate-500 hover:bg-slate-700"
                  }`}
                >
                  {company}
                  {companies.includes(company) && companyName !== company && (
                    <span className="ml-1 text-emerald-400">●</span>
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* Role */}
          <div>
            <label className="block text-sm font-medium mb-2">
              Role / Position
            </label>
            <input
              type="text"
              value={role}
              onChange={(e) => setRole(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-colors"
              placeholder="e.g., SDE-1, Backend Engineer, Data Scientist..."
            />
            <div className="flex flex-wrap gap-2 mt-3">
              {[
                "SDE-1",
                "SDE-2",
                "Backend Engineer",
                "Frontend Engineer",
                "Full Stack Developer",
                "Data Scientist",
              ].map((r) => (
                <button
                  key={r}
                  type="button"
                  onClick={() => setRole(r)}
                  className={`px-3 py-1 rounded-lg text-xs font-medium transition-colors ${
                    role === r
                      ? "bg-blue-600 text-white"
                      : "bg-slate-800 text-slate-400 hover:bg-slate-700"
                  }`}
                >
                  {r}
                </button>
              ))}
            </div>
          </div>

          {/* Duration */}
          <div>
            <label className="block text-sm font-medium mb-3">
              Test Duration
            </label>
            <div className="grid grid-cols-2 gap-3">
              {durations.map((d) => (
                <button
                  key={d.value}
                  type="button"
                  onClick={() => setDuration(d.value)}
                  className={`p-4 rounded-xl border text-left transition-all ${
                    duration === d.value
                      ? "bg-blue-600/10 border-blue-500 text-blue-400"
                      : "bg-slate-900 border-slate-700 hover:border-slate-600"
                  }`}
                >
                  <div className="font-semibold text-lg">{d.label}</div>
                  <div className="text-sm text-slate-400 mt-1">{d.desc}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Info box */}
          <div className="bg-blue-500/10 border border-blue-500/20 rounded-xl p-4">
            <p className="text-blue-400 text-sm">
              <strong>📚 How it works:</strong> Questions are fetched from a database of {companies.length > 0 ? `${companies.length}+` : "many"} companies&apos; 
              real interview problems from LeetCode. If your company is in the database, you&apos;ll get questions actually asked there!
            </p>
          </div>

          {/* Error */}
          {error && (
            <div className="bg-red-500/10 border border-red-500/20 text-red-400 rounded-xl p-4 text-sm">
              {error}
            </div>
          )}

          {/* Submit */}
          <button
            type="submit"
            disabled={isLoading}
            className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 disabled:opacity-50 disabled:cursor-not-allowed text-white py-4 rounded-xl font-semibold text-lg transition-all shadow-lg shadow-blue-500/25"
          >
            {isLoading ? (
              <span className="flex items-center justify-center gap-3">
                <svg
                  className="animate-spin h-5 w-5"
                  viewBox="0 0 24 24"
                  fill="none"
                >
                  <circle
                    className="opacity-25"
                    cx="12"
                    cy="12"
                    r="10"
                    stroke="currentColor"
                    strokeWidth="4"
                  />
                  <path
                    className="opacity-75"
                    fill="currentColor"
                    d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                  />
                </svg>
                Fetching Questions from {companyName || "Database"}...
              </span>
            ) : (
              "Generate Interview →"
            )}
          </button>
        </form>
      </div>
    </div>
  );
}
