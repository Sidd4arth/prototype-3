"use client";

import { useState, useEffect, useCallback, useRef } from "react";
import { useRouter } from "next/navigation";
import WebcamPanel from "./WebcamPanel";

/* ── Types ────────────────────────────────────────────────────────── */
interface Question {
  id: number;
  questionIndex: number;
  title: string;
  difficulty: string;
  description: string;
  examples: Array<{ input: string; output: string; explanation: string }>;
  testCases: Array<{ input: string; expected_output: string; is_hidden: boolean }>;
  starterCode: Record<string, string>;
}

interface SessionData {
  uid: string;
  companyName: string;
  role: string;
  duration: number;
  status: string;
  startedAt: string | null;
}

interface SubmissionResult {
  test_case_index: number;
  passed: boolean;
  output: string;
  expected?: string;
  time_ms: number;
  memory_kb: number;
}

interface WebcamEvent {
  timestamp: number;
  type: string;
  message: string;
  severity: "low" | "medium" | "high";
}

interface WarningToast {
  id: number;
  message: string;
  severity: string;
  exiting: boolean;
}

/* ── Component ────────────────────────────────────────────────────── */
export default function InterviewClient({
  session,
  questions,
}: {
  session: SessionData;
  questions: Question[];
}) {
  const router = useRouter();

  /* state */
  const [isStarted, setIsStarted] = useState(session.status === "in_progress");
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [language, setLanguage] = useState("python");
  const [codes, setCodes] = useState<Record<string, Record<string, string>>>({});
  const [timeLeft, setTimeLeft] = useState(session.duration * 60);
  const [isRunning, setIsRunning] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [consoleOutput, setConsoleOutput] = useState("");
  const [activeTab, setActiveTab] = useState<"description" | "testcases" | "submissions">("description");
  const [showConsole, setShowConsole] = useState(false);
  const [verdicts, setVerdicts] = useState<Record<number, string>>({});
  const [showEndConfirm, setShowEndConfirm] = useState(false);
  const [warningCount, setWarningCount] = useState(0);
  const [toasts, setToasts] = useState<WarningToast[]>([]);
  const [mobilePanel, setMobilePanel] = useState<"problem" | "code" | "webcam">("problem");
  const [webcamGlow, setWebcamGlow] = useState(false);

  /* refs */
  const webcamEventsRef = useRef<WebcamEvent[]>([]);
  const toastIdRef = useRef(0);

  const currentQuestion = questions[currentQuestionIndex];

  /* ── Initialise starter code ─────────────────────────────────────── */
  useEffect(() => {
    const initial: Record<string, Record<string, string>> = {};
    questions.forEach((q) => { initial[q.id] = { ...q.starterCode }; });
    setCodes(initial);
  }, [questions]);

  /* ── Sync time with server startedAt ─────────────────────────────── */
  useEffect(() => {
    if (session.startedAt && isStarted) {
      const elapsed = Math.floor((Date.now() - new Date(session.startedAt).getTime()) / 1000);
      setTimeLeft(Math.max(0, session.duration * 60 - elapsed));
    }
  }, [session.startedAt, session.duration, isStarted]);

  /* ── Countdown timer ─────────────────────────────────────────────── */
  useEffect(() => {
    if (!isStarted) return;
    const id = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) { clearInterval(id); handleEndSession(); return 0; }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isStarted]);

  /* ── Warning handler (called from WebcamPanel) ───────────────────── */
  const handleWarning = useCallback((msg: string, severity: "low" | "medium" | "high", _type: string) => {
    setWarningCount((c) => c + 1);

    // Glow effect on webcam box
    setWebcamGlow(true);
    setTimeout(() => setWebcamGlow(false), 1200);

    // Add toast
    const id = ++toastIdRef.current;
    setToasts((prev) => [...prev, { id, message: msg, severity, exiting: false }]);

    // Start exit animation after 3.5s, remove after 4s
    setTimeout(() => {
      setToasts((prev) => prev.map((t) => (t.id === id ? { ...t, exiting: true } : t)));
    }, 3500);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4000);
  }, []);

  /* ── Webcam events update ────────────────────────────────────────── */
  const handleEventsUpdate = useCallback((events: WebcamEvent[]) => {
    webcamEventsRef.current = events;
  }, []);

  /* ── Session start ───────────────────────────────────────────────── */
  const handleStartSession = async () => {
    try {
      const res = await fetch(`/api/sessions/${session.uid}/start`, { method: "POST" });
      if (res.ok) setIsStarted(true);
    } catch (err) {
      console.error("Failed to start session:", err);
    }
  };

  /* ── Session end ─────────────────────────────────────────────────── */
  const handleEndSession = useCallback(async () => {
    if (webcamEventsRef.current.length > 0) {
      try {
        await fetch(`/api/sessions/${session.uid}/webcam-log`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ events: webcamEventsRef.current }),
        });
      } catch { /* ignore */ }
    }
    try {
      await fetch(`/api/sessions/${session.uid}/complete`, { method: "POST" });
      router.push(`/results/${session.uid}`);
    } catch { /* ignore */ }
  }, [session.uid, router]);

  /* ── Code execution ──────────────────────────────────────────────── */
  const handleRunCode = async () => {
    if (!currentQuestion) return;
    setIsRunning(true); setShowConsole(true);
    setConsoleOutput("Running code against visible test cases…\n");
    try {
      const code = codes[currentQuestion.id]?.[language] || "";
      const res = await fetch(`/api/sessions/${session.uid}/submit`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ questionId: currentQuestion.id, language, code, submissionType: "run" }),
      });
      const data = await res.json();
      if (data.results) {
        let out = `Language: ${language}\n\n`;
        (data.results as SubmissionResult[]).forEach((r, i) => {
          out += `Test Case ${i + 1}: ${r.passed ? "✅ PASSED" : "❌ FAILED"}\n`;
          out += `  Output: ${r.output}\n`;
          if (r.expected) out += `  Expected: ${r.expected}\n`;
          out += `  Time: ${r.time_ms}ms | Memory: ${(r.memory_kb / 1024).toFixed(1)}MB\n\n`;
        });
        out += `\nResult: ${data.totalPassed}/${data.totalTests} passed`;
        setConsoleOutput(out);
      }
    } catch { setConsoleOutput("Error: execution failed."); }
    finally { setIsRunning(false); }
  };

  const handleSubmitCode = async () => {
    if (!currentQuestion) return;
    setIsSubmitting(true); setShowConsole(true);
    setConsoleOutput("Submitting against ALL test cases (incl. hidden)…\n");
    try {
      const code = codes[currentQuestion.id]?.[language] || "";
      const res = await fetch(`/api/sessions/${session.uid}/submit`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ questionId: currentQuestion.id, language, code, submissionType: "submit" }),
      });
      const data = await res.json();
      if (data.results) {
        let out = `=== SUBMISSION ===\nLanguage: ${language}\n\n`;
        (data.results as SubmissionResult[]).forEach((r, i) => {
          out += `Test Case ${i + 1}: ${r.passed ? "✅ PASSED" : "❌ FAILED"}\n`;
          out += `  Output: ${r.output}\n`;
          out += `  Time: ${r.time_ms}ms | Memory: ${(r.memory_kb / 1024).toFixed(1)}MB\n\n`;
        });
        out += `\nVerdict: ${data.verdict}\nPassed: ${data.totalPassed}/${data.totalTests}`;
        setConsoleOutput(out);
        setVerdicts((prev) => ({ ...prev, [currentQuestion.id]: data.verdict }));
      }
    } catch { setConsoleOutput("Error: submission failed."); }
    finally { setIsSubmitting(false); }
  };

  /* ── Helpers ─────────────────────────────────────────────────────── */
  const fmt = (s: number) => `${Math.floor(s / 60).toString().padStart(2, "0")}:${(s % 60).toString().padStart(2, "0")}`;
  const diffColor = (d: string) => d === "Easy" ? "text-emerald-400" : d === "Medium" ? "text-amber-400" : "text-red-400";

  /* ── Pre-start screen ────────────────────────────────────────────── */
  if (!isStarted) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <div className="max-w-lg w-full bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 text-center">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-3xl mx-auto mb-6">🎯</div>
          <h1 className="text-2xl font-bold mb-2">Ready to Begin?</h1>
          <p className="text-slate-400 mb-6">{session.companyName} — {session.role}</p>

          <div className="bg-slate-800/50 rounded-xl p-4 mb-6 text-left space-y-2">
            <Row label="Questions" value={String(questions.length)} />
            <Row label="Duration" value={`${session.duration} minutes`} />
            <Row label="Languages" value="Python, C++, Java, JS" />
          </div>

          <div className="bg-amber-500/10 border border-amber-500/20 rounded-xl p-4 mb-4 text-left">
            <p className="text-amber-400 text-sm">⚠️ Your webcam will be used for behavioral analysis. No video is recorded — only event logs are saved.</p>
          </div>
          <div className="bg-blue-500/10 border border-blue-500/20 rounded-xl p-4 mb-6 text-left">
            <p className="text-blue-400 text-sm">📱 On mobile? The interview will adapt to your screen. Swipe between Problem, Code, and Webcam tabs.</p>
          </div>

          <button onClick={handleStartSession} className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white py-3 rounded-xl font-semibold transition-all text-lg">
            Start Interview →
          </button>
        </div>
      </div>
    );
  }

  /* ── Main interview UI ───────────────────────────────────────────── */
  return (
    <div className="h-dvh flex flex-col overflow-hidden">
      {/* ═══ Top Bar ═══ */}
      <header className="bg-slate-900 border-b border-slate-800 px-3 py-2 flex items-center justify-between shrink-0 gap-2">
        <div className="flex items-center gap-2 min-w-0">
          <div className="w-6 h-6 rounded bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center font-bold text-[10px] shrink-0">M</div>
          <span className="font-semibold text-xs sm:text-sm truncate hidden sm:block">{session.companyName} — {session.role}</span>
          {/* Question tabs */}
          <div className="flex gap-0.5 sm:gap-1">
            {questions.map((q, i) => (
              <button key={q.id} onClick={() => setCurrentQuestionIndex(i)}
                className={`px-2 sm:px-3 py-1 rounded text-[10px] sm:text-xs font-medium transition-colors ${
                  i === currentQuestionIndex ? "bg-blue-600 text-white"
                  : verdicts[q.id] === "Accepted" ? "bg-emerald-500/20 text-emerald-400"
                  : verdicts[q.id] ? "bg-red-500/20 text-red-400"
                  : "bg-slate-800 text-slate-400 hover:bg-slate-700"
                }`}>
                Q{i + 1}
              </button>
            ))}
          </div>
        </div>

        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          {/* Warning counter */}
          {warningCount > 0 && (
            <div className="flex items-center gap-1 bg-amber-500/10 border border-amber-500/20 px-2 py-0.5 rounded-lg">
              <span className="text-amber-400 text-xs">⚠️</span>
              <span className="text-[10px] sm:text-xs text-amber-400 font-semibold">{warningCount}</span>
            </div>
          )}
          {/* Timer */}
          <div className={`font-mono text-base sm:text-lg font-bold ${
            timeLeft < 300 ? "text-red-400 timer-warning" : timeLeft < 600 ? "text-amber-400" : "text-emerald-400"
          }`}>
            {fmt(timeLeft)}
          </div>
          {/* End Session */}
          <button onClick={() => setShowEndConfirm(true)}
            className="bg-red-600/20 hover:bg-red-600/30 text-red-400 px-2 sm:px-3 py-1 sm:py-1.5 rounded-lg text-xs sm:text-sm font-medium transition-colors">
            End
          </button>
        </div>
      </header>

      {/* ═══ Mobile Tab Bar (≤768 px) ═══ */}
      <div className="flex md:hidden border-b border-slate-800 bg-slate-900 shrink-0">
        {(["problem", "code", "webcam"] as const).map((tab) => (
          <button key={tab} onClick={() => setMobilePanel(tab)}
            className={`flex-1 py-2.5 text-xs font-semibold uppercase tracking-wide transition-colors ${
              mobilePanel === tab ? "text-blue-400 border-b-2 border-blue-500 bg-slate-800/50" : "text-slate-500"
            }`}>
            {tab === "problem" ? "📄 Problem" : tab === "code" ? "💻 Code" : `📷 Webcam ${warningCount > 0 ? `(${warningCount})` : ""}`}
          </button>
        ))}
      </div>

      {/* ═══ Main Content ═══ */}
      <div className="flex-1 flex overflow-hidden">
        {/* ── Left Panel: Problem ──────────────────────────────────── */}
        <div className={`${mobilePanel === "problem" ? "flex" : "hidden"} md:flex flex-col w-full md:w-[45%] border-r border-slate-800 overflow-hidden`}>
          <div className="flex border-b border-slate-800 shrink-0">
            {([
              { key: "description" as const, label: "Description" },
              { key: "testcases" as const, label: "Test Cases" },
              { key: "submissions" as const, label: "Submissions" },
            ]).map((tab) => (
              <button key={tab.key} onClick={() => setActiveTab(tab.key)}
                className={`px-3 sm:px-4 py-2 text-xs sm:text-sm font-medium transition-colors ${
                  activeTab === tab.key ? "text-white border-b-2 border-blue-500" : "text-slate-400 hover:text-slate-300"
                }`}>
                {tab.label}
              </button>
            ))}
          </div>

          <div className="flex-1 overflow-y-auto p-4 sm:p-5">
            {activeTab === "description" && currentQuestion && (
              <div>
                <div className="flex items-center gap-2 mb-4 flex-wrap">
                  <h2 className="text-lg sm:text-xl font-bold">{currentQuestion.questionIndex + 1}. {currentQuestion.title}</h2>
                  <span className={`text-xs font-medium ${diffColor(currentQuestion.difficulty)}`}>{currentQuestion.difficulty}</span>
                </div>
                <div className="prose prose-invert prose-sm max-w-none">
                  {currentQuestion.description.split("\n").map((line, i) => (
                    <p key={i} className="text-slate-300 leading-relaxed text-sm">{line}</p>
                  ))}
                </div>
                <div className="mt-6 space-y-3">
                  {currentQuestion.examples.map((ex, i) => (
                    <div key={i} className="bg-slate-800/50 rounded-xl p-3 sm:p-4 border border-slate-700/50">
                      <div className="text-sm font-medium text-slate-300 mb-2">Example {i + 1}:</div>
                      <div className="space-y-1 text-xs sm:text-sm font-mono">
                        <div><span className="text-slate-500">Input: </span><span className="text-slate-300">{ex.input}</span></div>
                        <div><span className="text-slate-500">Output: </span><span className="text-slate-300">{ex.output}</span></div>
                        {ex.explanation && <div className="mt-1"><span className="text-slate-500">Explanation: </span><span className="text-slate-400">{ex.explanation}</span></div>}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
            {activeTab === "testcases" && currentQuestion && (
              <div className="space-y-3">
                <h3 className="font-semibold mb-3">Visible Test Cases ({currentQuestion.testCases.length})</h3>
                {currentQuestion.testCases.map((tc, i) => (
                  <div key={i} className="bg-slate-800/50 rounded-xl p-3 border border-slate-700/50">
                    <div className="text-xs font-medium text-slate-400 mb-1">Test Case {i + 1}</div>
                    <div className="space-y-1 text-xs sm:text-sm font-mono">
                      <div><span className="text-slate-500">Input: </span><span className="text-slate-300">{tc.input}</span></div>
                      <div><span className="text-slate-500">Expected: </span><span className="text-slate-300">{tc.expected_output}</span></div>
                    </div>
                  </div>
                ))}
                <div className="bg-slate-800/30 rounded-xl p-3 border border-dashed border-slate-700 text-center">
                  <p className="text-slate-500 text-xs">+ Hidden test cases will be run on Submit</p>
                </div>
              </div>
            )}
            {activeTab === "submissions" && (
              <div className="text-center text-slate-500 py-12 text-sm">Submit your code to see results here</div>
            )}
          </div>
        </div>

        {/* ── Middle Panel: Code Editor ────────────────────────────── */}
        <div className={`${mobilePanel === "code" ? "flex" : "hidden"} md:flex flex-col w-full md:flex-1 overflow-hidden`}>
          <div className="flex items-center justify-between px-3 py-2 bg-slate-900 border-b border-slate-800 shrink-0">
            <select value={language} onChange={(e) => setLanguage(e.target.value)}
              className="bg-slate-800 border border-slate-700 rounded-lg px-2 py-1 text-xs sm:text-sm text-white focus:outline-none focus:border-blue-500">
              <option value="python">Python</option>
              <option value="cpp">C++</option>
              <option value="java">Java</option>
              <option value="javascript">JavaScript</option>
            </select>
            <div className="flex gap-1.5">
              <button onClick={handleRunCode} disabled={isRunning || isSubmitting}
                className="bg-slate-700 hover:bg-slate-600 disabled:opacity-50 text-white px-3 py-1 rounded-lg text-xs font-medium transition-colors flex items-center gap-1.5">
                {isRunning ? <><Spinner /> Run…</> : <>▶ Run</>}
              </button>
              <button onClick={handleSubmitCode} disabled={isRunning || isSubmitting}
                className="bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white px-3 py-1 rounded-lg text-xs font-medium transition-colors flex items-center gap-1.5">
                {isSubmitting ? <><Spinner /> …</> : <>✓ Submit</>}
              </button>
            </div>
          </div>
          <div className="flex-1 overflow-hidden flex flex-col">
            <div className="flex-1 overflow-hidden">
              <textarea
                value={codes[currentQuestion?.id]?.[language] || ""}
                onChange={(e) => {
                  if (!currentQuestion) return;
                  setCodes((prev) => ({
                    ...prev,
                    [currentQuestion.id]: { ...prev[currentQuestion.id], [language]: e.target.value },
                  }));
                }}
                className="w-full h-full bg-[#1e1e2e] text-slate-200 font-mono text-xs sm:text-sm p-3 sm:p-4 resize-none focus:outline-none leading-6"
                spellCheck={false}
                placeholder="// Write your code here…"
              />
            </div>
            {showConsole && (
              <div className="h-36 sm:h-44 border-t border-slate-800 bg-slate-950 flex flex-col shrink-0">
                <div className="flex items-center justify-between px-3 py-1 bg-slate-900 border-b border-slate-800">
                  <span className="text-[10px] sm:text-xs font-medium text-slate-400">Console</span>
                  <button onClick={() => setShowConsole(false)} className="text-slate-500 hover:text-slate-300 text-xs">✕</button>
                </div>
                <pre className="flex-1 overflow-y-auto p-2 sm:p-3 text-[10px] sm:text-xs font-mono text-slate-300 whitespace-pre-wrap">{consoleOutput}</pre>
              </div>
            )}
          </div>
        </div>

        {/* ── Right Panel: Webcam (always visible on desktop, tab on mobile) ─ */}
        <div className={`${mobilePanel === "webcam" ? "flex" : "hidden"} md:flex flex-col w-full md:w-[220px] lg:w-[260px] border-l border-slate-800 bg-slate-900/50 p-3 gap-3 overflow-y-auto`}>
          <div className={`transition-shadow rounded-xl ${webcamGlow ? "webcam-glow" : ""}`}>
            <WebcamPanel isStarted={isStarted} onEventsUpdate={handleEventsUpdate} onWarning={handleWarning} />
          </div>

          {/* Stats below webcam */}
          <div className="bg-slate-800/50 rounded-xl p-3 space-y-2">
            <h4 className="text-[10px] uppercase tracking-wider text-slate-500 font-semibold">Behavior Monitor</h4>
            <div className="flex items-center justify-between">
              <span className="text-xs text-slate-400">Warnings</span>
              <span className={`text-xs font-bold ${warningCount > 5 ? "text-red-400" : warningCount > 2 ? "text-amber-400" : "text-emerald-400"}`}>{warningCount}</span>
            </div>
            <div className="w-full bg-slate-700 rounded-full h-1.5">
              <div className={`h-1.5 rounded-full transition-all duration-500 ${warningCount > 5 ? "bg-red-500" : warningCount > 2 ? "bg-amber-500" : "bg-emerald-500"}`}
                style={{ width: `${Math.min(100, warningCount * 10)}%` }} />
            </div>
            <p className="text-[10px] text-slate-500 leading-tight">
              {warningCount === 0 ? "Great! No issues detected yet." :
               warningCount <= 3 ? "Minor issues detected. Stay focused!" :
               warningCount <= 6 ? "Several warnings. Maintain posture & focus." :
               "Too many warnings — this affects your score."}
            </p>
          </div>

          {/* Recent warnings log */}
          <div className="bg-slate-800/50 rounded-xl p-3">
            <h4 className="text-[10px] uppercase tracking-wider text-slate-500 font-semibold mb-2">Recent Alerts</h4>
            {webcamEventsRef.current.length === 0 ? (
              <p className="text-[10px] text-slate-600 italic">No alerts yet</p>
            ) : (
              <div className="space-y-1.5 max-h-40 overflow-y-auto">
                {webcamEventsRef.current.slice(-8).reverse().map((evt, i) => (
                  <div key={i} className="flex items-start gap-1.5">
                    <span className={`mt-0.5 w-1.5 h-1.5 rounded-full shrink-0 ${
                      evt.severity === "high" ? "bg-red-400" : evt.severity === "medium" ? "bg-amber-400" : "bg-blue-400"
                    }`} />
                    <div>
                      <p className="text-[10px] text-slate-300 leading-tight">{evt.message}</p>
                      <p className="text-[9px] text-slate-600">{new Date(evt.timestamp).toLocaleTimeString()}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* ═══ Warning Toast Overlays ═══ */}
      <div className="fixed top-14 sm:top-16 right-2 sm:right-4 z-50 flex flex-col gap-2 pointer-events-none"
           style={{ maxWidth: "min(360px, calc(100vw - 16px))" }}>
        {toasts.map((t) => (
          <div key={t.id}
            className={`pointer-events-auto px-4 py-3 rounded-xl text-sm font-semibold shadow-2xl flex items-center gap-2.5 ${
              t.exiting ? "opacity-0 translate-x-full transition-all duration-300" : "webcam-warning"
            } ${
              t.severity === "high" ? "bg-red-500 text-white warning-shake"
              : t.severity === "medium" ? "bg-amber-500 text-black"
              : "bg-blue-500 text-white"
            }`}>
            <span className="text-lg">{t.severity === "high" ? "🚨" : t.severity === "medium" ? "⚠️" : "ℹ️"}</span>
            <span className="flex-1">{t.message}</span>
            <span className={`w-2 h-2 rounded-full animate-pulse ${
              t.severity === "high" ? "bg-white" : t.severity === "medium" ? "bg-black/30" : "bg-white/60"
            }`} />
          </div>
        ))}
      </div>

      {/* ═══ End-Session Modal ═══ */}
      {showEndConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 max-w-md w-full">
            <h3 className="text-xl font-bold mb-2">End Session?</h3>
            <p className="text-slate-400 mb-6 text-sm">
              Are you sure? You won&apos;t be able to submit any more code.
              {warningCount > 0 && ` You have ${warningCount} behavioral warning${warningCount !== 1 ? "s" : ""} recorded.`}
            </p>
            <div className="flex gap-3">
              <button onClick={() => setShowEndConfirm(false)}
                className="flex-1 bg-slate-800 hover:bg-slate-700 text-white py-2.5 rounded-xl font-medium transition-colors text-sm">
                Continue
              </button>
              <button onClick={handleEndSession}
                className="flex-1 bg-red-600 hover:bg-red-700 text-white py-2.5 rounded-xl font-medium transition-colors text-sm">
                End Session
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/* ── Small helpers ─────────────────────────────────────────────────── */
function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between text-sm">
      <span className="text-slate-400">{label}</span>
      <span>{value}</span>
    </div>
  );
}

function Spinner() {
  return (
    <svg className="animate-spin h-3 w-3" viewBox="0 0 24 24" fill="none">
      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
    </svg>
  );
}
