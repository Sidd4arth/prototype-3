"use client";

import { useEffect, useRef, useState, useCallback } from "react";

interface WebcamEvent {
  timestamp: number;
  type: string;
  message: string;
  severity: "low" | "medium" | "high";
}

interface WebcamPanelProps {
  isStarted: boolean;
  onEventsUpdate: (events: WebcamEvent[]) => void;
  onWarning: (msg: string, severity: "low" | "medium" | "high", type: string) => void;
}

export default function WebcamPanel({ isStarted, onEventsUpdate, onWarning }: WebcamPanelProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const animFrameRef = useRef<number>(0);
  const eventsRef = useRef<WebcamEvent[]>([]);

  const [camStatus, setCamStatus] = useState<"off" | "requesting" | "live" | "denied" | "unavailable">("off");
  const [simTime, setSimTime] = useState(0);

  // ── Try to get real camera ────────────────────────────────────────
  const requestCamera = useCallback(async () => {
    setCamStatus("requesting");
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { width: { ideal: 320 }, height: { ideal: 240 }, facingMode: "user" },
        audio: false,
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }
      setCamStatus("live");
    } catch (err) {
      console.warn("Camera error:", err);
      if (err instanceof DOMException && err.name === "NotAllowedError") {
        setCamStatus("denied");
      } else {
        setCamStatus("unavailable");
      }
    }
  }, []);

  // Auto-request on start
  useEffect(() => {
    if (isStarted && camStatus === "off") {
      requestCamera();
    }
  }, [isStarted, camStatus, requestCamera]);

  // ── Canvas simulation when no real camera ─────────────────────────
  useEffect(() => {
    if (!isStarted) return;
    if (camStatus === "live") return; // real camera renders itself

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let frame = 0;
    const draw = () => {
      frame++;
      const w = canvas.width;
      const h = canvas.height;

      // Background gradient
      const bg = ctx.createLinearGradient(0, 0, 0, h);
      bg.addColorStop(0, "#1a1a2e");
      bg.addColorStop(1, "#16213e");
      ctx.fillStyle = bg;
      ctx.fillRect(0, 0, w, h);

      // Subtle breathing movement
      const breathe = Math.sin(frame * 0.03) * 2;
      const sway = Math.sin(frame * 0.015) * 3;

      const cx = w / 2 + sway;
      const cy = h / 2 + breathe - 10;

      // Body / shoulders
      ctx.beginPath();
      ctx.ellipse(cx, cy + 65, 55, 30, 0, Math.PI, 0, true);
      ctx.fillStyle = "#334155";
      ctx.fill();

      // Neck
      ctx.fillStyle = "#64748b";
      ctx.fillRect(cx - 8, cy + 28, 16, 12);

      // Head
      ctx.beginPath();
      ctx.ellipse(cx, cy, 28, 32, 0, 0, Math.PI * 2);
      ctx.fillStyle = "#64748b";
      ctx.fill();

      // Eyes
      const eyeY = cy - 4;
      const blinkCycle = frame % 180;
      const eyeH = blinkCycle < 5 ? 1 : 4; // blink every ~3 seconds

      // Left eye
      ctx.beginPath();
      ctx.ellipse(cx - 10, eyeY, 4, eyeH, 0, 0, Math.PI * 2);
      ctx.fillStyle = "#e2e8f0";
      ctx.fill();
      if (eyeH > 1) {
        ctx.beginPath();
        ctx.arc(cx - 10 + Math.sin(frame * 0.02) * 1.5, eyeY, 2, 0, Math.PI * 2);
        ctx.fillStyle = "#1e293b";
        ctx.fill();
      }

      // Right eye
      ctx.beginPath();
      ctx.ellipse(cx + 10, eyeY, 4, eyeH, 0, 0, Math.PI * 2);
      ctx.fillStyle = "#e2e8f0";
      ctx.fill();
      if (eyeH > 1) {
        ctx.beginPath();
        ctx.arc(cx + 10 + Math.sin(frame * 0.02) * 1.5, eyeY, 2, 0, Math.PI * 2);
        ctx.fillStyle = "#1e293b";
        ctx.fill();
      }

      // Mouth (slight smile)
      ctx.beginPath();
      ctx.arc(cx, cy + 12, 8, 0.1, Math.PI - 0.1);
      ctx.strokeStyle = "#94a3b8";
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // "LIVE" badge
      ctx.fillStyle = "#ef4444";
      ctx.beginPath();
      ctx.arc(w - 30, 18, 4, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = "#ffffff";
      ctx.font = "bold 10px system-ui";
      ctx.textAlign = "left";
      ctx.fillText("SIM", w - 24, 22);

      // Scan line effect
      const scanY = (frame * 2) % h;
      ctx.strokeStyle = "rgba(59, 130, 246, 0.08)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(0, scanY);
      ctx.lineTo(w, scanY);
      ctx.stroke();

      animFrameRef.current = requestAnimationFrame(draw);
    };

    animFrameRef.current = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(animFrameRef.current);
  }, [isStarted, camStatus]);

  // ── Tick the sim timer (for display only) ─────────────────────────
  useEffect(() => {
    if (!isStarted) return;
    const interval = setInterval(() => setSimTime((t) => t + 1), 1000);
    return () => clearInterval(interval);
  }, [isStarted]);

  // ── Generate behavioural warnings ─────────────────────────────────
  useEffect(() => {
    if (!isStarted) return;

    const types: Array<{ type: string; message: string; severity: "low" | "medium" | "high" }> = [
      { type: "looking_away",    message: "👀 Looking away from screen", severity: "medium" },
      { type: "bad_posture",     message: "🪑 Poor posture — sit upright", severity: "low" },
      { type: "no_face",         message: "😶 Face not detected",        severity: "high" },
      { type: "head_movement",   message: "🔄 Excessive head movement",  severity: "low" },
      { type: "multiple_faces",  message: "👥 Multiple faces detected",  severity: "high" },
      { type: "slouching",       message: "📐 Slouching detected",       severity: "medium" },
      { type: "looking_away",    message: "👀 Eyes off screen",          severity: "medium" },
    ];

    // First warning after 6s
    const t1 = setTimeout(() => {
      fire(types[0]);
    }, 6000);

    // Second warning after 14s
    const t2 = setTimeout(() => {
      fire(types[1]);
    }, 14000);

    // Then periodic
    const interval = setInterval(() => {
      if (Math.random() < 0.35) {
        const w = types[Math.floor(Math.random() * types.length)];
        fire(w);
      }
    }, 7000);

    function fire(w: (typeof types)[number]) {
      const evt: WebcamEvent = { timestamp: Date.now(), type: w.type, message: w.message, severity: w.severity };
      eventsRef.current = [...eventsRef.current, evt];
      onEventsUpdate(eventsRef.current);
      onWarning(w.message, w.severity, w.type);
    }

    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      clearInterval(interval);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isStarted]);

  // ── Cleanup camera on unmount ─────────────────────────────────────
  useEffect(() => {
    return () => {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((t) => t.stop());
      }
      cancelAnimationFrame(animFrameRef.current);
    };
  }, []);

  if (!isStarted) return null;

  const fmtTime = (s: number) =>
    `${Math.floor(s / 60).toString().padStart(2, "0")}:${(s % 60).toString().padStart(2, "0")}`;

  return (
    <div className="flex flex-col">
      {/* Camera feed area */}
      <div className="relative bg-slate-900 rounded-xl overflow-hidden border border-slate-700"
           style={{ aspectRatio: "4/3" }}>
        {/* Real camera video — always mounted */}
        <video
          ref={videoRef}
          autoPlay
          muted
          playsInline
          className="absolute inset-0 w-full h-full object-cover"
          style={{
            transform: "scaleX(-1)",
            display: camStatus === "live" ? "block" : "none",
          }}
        />

        {/* Canvas simulation — shown when no real camera */}
        <canvas
          ref={canvasRef}
          width={320}
          height={240}
          className="absolute inset-0 w-full h-full"
          style={{ display: camStatus === "live" ? "none" : "block" }}
        />

        {/* Overlay badges */}
        <div className="absolute top-2 left-2 flex items-center gap-1.5">
          <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wide ${
            camStatus === "live"
              ? "bg-emerald-500/90 text-white"
              : "bg-blue-500/90 text-white"
          }`}>
            <span className={`w-1.5 h-1.5 rounded-full ${
              camStatus === "live" ? "bg-white animate-pulse" : "bg-white/70 animate-pulse"
            }`} />
            {camStatus === "live" ? "LIVE" : "SIM"}
          </span>
        </div>

        {/* Recording timer */}
        <div className="absolute bottom-2 left-2">
          <span className="text-[10px] font-mono text-slate-400 bg-black/40 px-1.5 py-0.5 rounded">
            REC {fmtTime(simTime)}
          </span>
        </div>

        {/* Status label */}
        <div className="absolute bottom-2 right-2">
          <span className={`text-[10px] px-1.5 py-0.5 rounded font-medium ${
            camStatus === "live"
              ? "bg-emerald-500/20 text-emerald-400"
              : camStatus === "denied"
                ? "bg-red-500/20 text-red-400"
                : "bg-slate-700/80 text-slate-400"
          }`}>
            {camStatus === "live" ? "Camera Active" :
             camStatus === "denied" ? "Access Denied" :
             camStatus === "unavailable" ? "Simulated" : "Starting…"}
          </span>
        </div>
      </div>

      {/* Retry button if denied */}
      {(camStatus === "denied" || camStatus === "unavailable") && (
        <button
          onClick={requestCamera}
          className="mt-2 text-xs text-blue-400 hover:text-blue-300 underline text-center"
        >
          🔄 Try enabling real camera
        </button>
      )}
    </div>
  );
}
