import Link from "next/link";
import { db } from "@/db";
import { sessions } from "@/db/schema";
import { desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  let recentSessions: Array<{
    id: number;
    uid: string;
    companyName: string;
    role: string;
    lpa: string;
    duration: number;
    status: string;
    createdAt: Date;
  }> = [];

  try {
    recentSessions = await db
      .select()
      .from(sessions)
      .orderBy(desc(sessions.createdAt))
      .limit(5);
  } catch {
    // Table may not exist yet
  }

  return (
    <div className="min-h-screen">
      {/* Navigation */}
      <nav className="border-b border-slate-800 bg-slate-950/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center font-bold text-sm">
              M
            </div>
            <span className="text-xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
              MockPrep
            </span>
          </div>
          <Link
            href="/new-session"
            className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 rounded-lg font-medium transition-colors"
          >
            Start Interview
          </Link>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-6 pt-20 pb-16">
        <div className="text-center max-w-3xl mx-auto">
          <div className="inline-flex items-center gap-2 bg-blue-500/10 border border-blue-500/20 text-blue-400 px-4 py-1.5 rounded-full text-sm font-medium mb-6">
            <span className="w-2 h-2 bg-blue-400 rounded-full animate-pulse" />
            AI-Powered Mock Interviews
          </div>
          <h1 className="text-5xl md:text-6xl font-bold mb-6 leading-tight">
            Ace Your Next{" "}
            <span className="bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
              Coding Interview
            </span>
          </h1>
          <p className="text-xl text-slate-400 mb-10 leading-relaxed">
            Practice with AI-generated questions tailored to your target company
            and role. Get real-time behavioral analysis and detailed feedback.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              href="/new-session"
              className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8 py-3.5 rounded-xl font-semibold text-lg transition-all shadow-lg shadow-blue-500/25"
            >
              Start Mock Interview →
            </Link>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="max-w-7xl mx-auto px-6 py-16">
        <div className="grid md:grid-cols-3 gap-6">
          <FeatureCard
            icon="🧠"
            title="AI Question Generation"
            description="Questions generated based on your target company, role, and package using AI. Tailored difficulty and topics."
            color="blue"
          />
          <FeatureCard
            icon="💻"
            title="LeetCode-style Coding"
            description="Full-featured code editor with syntax highlighting, multiple language support, and real-time test execution."
            color="purple"
          />
          <FeatureCard
            icon="📊"
            title="Detailed Analytics"
            description="Performance breakdown with charts, behavioral analysis from webcam monitoring, and AI-generated feedback."
            color="pink"
          />
          <FeatureCard
            icon="📷"
            title="Webcam Analysis"
            description="Real-time posture and gaze detection using MediaPipe. Get warnings for looking away or poor posture."
            color="green"
          />
          <FeatureCard
            icon="⏱️"
            title="Timed Sessions"
            description="Configurable session durations (30/45/60/90 min) with live countdown timer, just like real interviews."
            color="yellow"
          />
          <FeatureCard
            icon="🔒"
            title="Privacy First"
            description="Webcam processing happens entirely in your browser. No video is ever uploaded — only event logs."
            color="red"
          />
        </div>
      </section>

      {/* Recent Sessions */}
      {recentSessions.length > 0 && (
        <section className="max-w-7xl mx-auto px-6 py-16">
          <h2 className="text-2xl font-bold mb-6">Recent Sessions</h2>
          <div className="space-y-3">
            {recentSessions.map((session) => (
              <Link
                key={session.id}
                href={
                  session.status === "completed"
                    ? `/results/${session.uid}`
                    : session.status === "ready" || session.status === "in_progress"
                    ? `/interview/${session.uid}`
                    : "#"
                }
                className="block bg-slate-900 border border-slate-800 rounded-xl p-5 hover:border-slate-700 transition-colors"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-semibold text-lg">
                      {session.companyName} — {session.role}
                    </h3>
                    <p className="text-slate-400 text-sm mt-1">
                      {session.lpa} LPA • {session.duration} min •{" "}
                      {new Date(session.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                  <StatusBadge status={session.status} />
                </div>
              </Link>
            ))}
          </div>
        </section>
      )}

      {/* How It Works */}
      <section className="max-w-7xl mx-auto px-6 py-16">
        <h2 className="text-3xl font-bold text-center mb-12">How It Works</h2>
        <div className="grid md:grid-cols-4 gap-8">
          {[
            {
              step: "1",
              title: "Configure",
              desc: "Enter your target company, role, package, and session duration.",
            },
            {
              step: "2",
              title: "Generate",
              desc: "AI generates coding questions tailored to your interview profile.",
            },
            {
              step: "3",
              title: "Practice",
              desc: "Solve problems in a LeetCode-style editor with webcam monitoring.",
            },
            {
              step: "4",
              title: "Review",
              desc: "Get detailed performance analytics and AI-generated feedback.",
            },
          ].map((item) => (
            <div key={item.step} className="text-center">
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-xl font-bold mx-auto mb-4">
                {item.step}
              </div>
              <h3 className="font-semibold text-lg mb-2">{item.title}</h3>
              <p className="text-slate-400 text-sm">{item.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-800 mt-16">
        <div className="max-w-7xl mx-auto px-6 py-8 flex items-center justify-between text-slate-500 text-sm">
          <span>© 2025 MockPrep. AI-Powered Interview Preparation.</span>
          <span>Built with Next.js + PostgreSQL</span>
        </div>
      </footer>
    </div>
  );
}

function FeatureCard({
  icon,
  title,
  description,
  color,
}: {
  icon: string;
  title: string;
  description: string;
  color: string;
}) {
  const colors: Record<string, string> = {
    blue: "from-blue-500/10 to-blue-500/5 border-blue-500/20",
    purple: "from-purple-500/10 to-purple-500/5 border-purple-500/20",
    pink: "from-pink-500/10 to-pink-500/5 border-pink-500/20",
    green: "from-emerald-500/10 to-emerald-500/5 border-emerald-500/20",
    yellow: "from-amber-500/10 to-amber-500/5 border-amber-500/20",
    red: "from-red-500/10 to-red-500/5 border-red-500/20",
  };

  return (
    <div
      className={`bg-gradient-to-br ${colors[color] || colors.blue} border rounded-xl p-6`}
    >
      <div className="text-3xl mb-4">{icon}</div>
      <h3 className="font-semibold text-lg mb-2">{title}</h3>
      <p className="text-slate-400 text-sm leading-relaxed">{description}</p>
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  const styles: Record<string, string> = {
    pending: "bg-slate-500/20 text-slate-400",
    generating: "bg-amber-500/20 text-amber-400",
    ready: "bg-blue-500/20 text-blue-400",
    in_progress: "bg-purple-500/20 text-purple-400",
    completed: "bg-emerald-500/20 text-emerald-400",
  };

  const labels: Record<string, string> = {
    pending: "Pending",
    generating: "Generating",
    ready: "Ready",
    in_progress: "In Progress",
    completed: "Completed",
  };

  return (
    <span
      className={`px-3 py-1 rounded-full text-xs font-medium ${styles[status] || styles.pending}`}
    >
      {labels[status] || status}
    </span>
  );
}
