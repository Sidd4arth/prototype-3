import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { sessions, questions, submissions } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ uid: string }> }
) {
  try {
    const { uid } = await params;
    const body = await request.json();
    const { questionId, language, code, submissionType } = body;

    if (!questionId || !language || !code || !submissionType) {
      return NextResponse.json(
        { error: "Missing required fields" },
        { status: 400 }
      );
    }

    // Verify session
    const [session] = await db
      .select()
      .from(sessions)
      .where(eq(sessions.uid, uid));

    if (!session || session.status !== "in_progress") {
      return NextResponse.json(
        { error: "Session not active" },
        { status: 400 }
      );
    }

    // Get question with test cases
    const [question] = await db
      .select()
      .from(questions)
      .where(eq(questions.id, questionId));

    if (!question) {
      return NextResponse.json(
        { error: "Question not found" },
        { status: 404 }
      );
    }

    // Simulate code execution (in production, would use Judge0)
    const testCases = question.testCases as Array<{
      input: string;
      expected_output: string;
      is_hidden: boolean;
    }>;

    // For "run", only test visible cases; for "submit", test all
    const casesToTest =
      submissionType === "run"
        ? testCases.filter((tc) => !tc.is_hidden)
        : testCases;

    // Simulate execution results
    const results = casesToTest.map((tc, index) => {
      // Simulate: randomly pass or fail based on code content
      const hasLogic = code.length > 100;
      const passed = hasLogic && Math.random() > 0.3;
      return {
        test_case_index: index,
        passed,
        output: passed ? tc.expected_output : "Wrong output",
        expected: submissionType === "run" ? tc.expected_output : undefined,
        time_ms: Math.floor(Math.random() * 100) + 10,
        memory_kb: Math.floor(Math.random() * 5000) + 1000,
        is_hidden: tc.is_hidden,
      };
    });

    const totalPassed = results.filter((r) => r.passed).length;
    const totalTests = results.length;

    let verdict: string;
    if (totalPassed === totalTests) {
      verdict = "Accepted";
    } else if (code.length < 50) {
      verdict = "Compile Error";
    } else {
      verdict = "Wrong Answer";
    }

    // Only return visible results to client
    const clientResults = results.map((r) => ({
      ...r,
      expected: r.is_hidden ? undefined : r.expected,
    }));

    const [submission] = await db
      .insert(submissions)
      .values({
        sessionId: session.id,
        questionId,
        language,
        code,
        submissionType,
        results: clientResults,
        totalPassed,
        totalTests,
        verdict,
      })
      .returning();

    return NextResponse.json({
      id: submission.id,
      results: clientResults.filter((r) => !r.is_hidden || submissionType === "submit"),
      totalPassed,
      totalTests,
      verdict,
    });
  } catch (error) {
    console.error("Submission error:", error);
    return NextResponse.json(
      { error: "Failed to process submission" },
      { status: 500 }
    );
  }
}
