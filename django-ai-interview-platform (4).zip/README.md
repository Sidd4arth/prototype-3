# MockPrep — AI Mock Interview Platform 🎯

Practice coding interviews with AI-generated questions tailored to your target company and role. Get real-time behavioral analysis and detailed feedback.

## Tech Stack

- **Framework**: Next.js 16 (App Router)
- **Database**: PostgreSQL
- **ORM**: Drizzle ORM
- **Styling**: Tailwind CSS 4
- **Language**: TypeScript

---

## Local Setup Guide

### Prerequisites

Make sure you have installed:

1. **Node.js 18+** — [Download](https://nodejs.org/)
2. **PostgreSQL 14+** — [Download](https://www.postgresql.org/download/)
3. **Git** (optional) — [Download](https://git-scm.com/)

---

### Step 1: Install Dependencies

Open terminal in VS Code (`Ctrl + `` ` or `View > Terminal`) and run:

```bash
npm install
```

---

### Step 2: Set Up PostgreSQL Database

#### Option A: Using PostgreSQL installed locally

1. **Start PostgreSQL** (if not running):
   - **Windows**: Search "Services" → Start "PostgreSQL"
   - **Mac**: `brew services start postgresql`
   - **Linux**: `sudo systemctl start postgresql`

2. **Create the database**:
   ```bash
   # Connect to PostgreSQL
   psql -U postgres
   
   # Create database (in psql shell)
   CREATE DATABASE app_db;
   
   # Exit
   \q
   ```

#### Option B: Using Docker (easier)

```bash
docker run --name mockprep-db \
  -e POSTGRES_USER=postgres \
  -e POSTGRES_PASSWORD=postgres \
  -e POSTGRES_DB=app_db \
  -p 5432:5432 \
  -d postgres:15
```

---

### Step 3: Configure Environment Variables

The `.env` file should already exist with:

```env
DATABASE_URL=postgresql://postgres:postgres@127.0.0.1:5432/app_db
```

If your PostgreSQL uses different credentials, update accordingly:

```env
DATABASE_URL=postgresql://USERNAME:PASSWORD@localhost:5432/app_db
```

---

### Step 4: Push Database Schema

Run this to create the database tables:

```bash
npx drizzle-kit push
```

You should see:
```
[✓] Changes applied
```

---

### Step 5: Start Development Server

```bash
npm run dev
```

Open your browser to: **http://localhost:3000**

---

## Available Scripts

| Command | Description |
|---------|-------------|
| `npm run dev` | Start development server (http://localhost:3000) |
| `npm run build` | Build for production |
| `npm run start` | Start production server |
| `npm run lint` | Run ESLint |
| `npm run typecheck` | Run TypeScript type checking |
| `npx drizzle-kit push` | Push schema changes to database |
| `npx drizzle-kit studio` | Open Drizzle Studio (database GUI) |

---

## Project Structure

```
├── src/
│   ├── app/
│   │   ├── page.tsx                    # Landing page
│   │   ├── layout.tsx                  # Root layout
│   │   ├── globals.css                 # Global styles
│   │   ├── new-session/
│   │   │   └── page.tsx                # Session setup form
│   │   ├── interview/
│   │   │   └── [uid]/
│   │   │       ├── page.tsx            # Interview page (server)
│   │   │       └── InterviewClient.tsx # Coding environment (client)
│   │   ├── results/
│   │   │   └── [uid]/
│   │   │       ├── page.tsx            # Results page (server)
│   │   │       └── ResultsCharts.tsx   # Charts component (client)
│   │   └── api/
│   │       ├── health/route.ts         # Health check
│   │       └── sessions/
│   │           ├── route.ts            # Create/list sessions
│   │           └── [uid]/
│   │               ├── route.ts        # Get session details
│   │               ├── start/route.ts  # Start interview
│   │               ├── submit/route.ts # Submit code
│   │               ├── complete/route.ts # End session
│   │               └── webcam-log/route.ts # Save webcam events
│   ├── db/
│   │   ├── index.ts                    # Database connection
│   │   └── schema.ts                   # Drizzle schema
│   └── lib/
│       └── question-generator.ts       # Question generation logic
├── .env                                # Environment variables
├── drizzle.config.json                 # Drizzle configuration
├── package.json
├── tsconfig.json
└── README.md
```

---

## Usage Guide

### 1. Create a Mock Interview

1. Go to **http://localhost:3000**
2. Click **"Start Interview"**
3. Fill in:
   - **Company**: e.g., Google, Amazon
   - **Role**: e.g., SDE-1, Backend Engineer
   - **LPA**: Expected package (affects difficulty)
   - **Duration**: 30/45/60/90 minutes
4. Click **"Generate Interview"**

### 2. Take the Interview

- **Left Panel**: Problem description, examples, test cases
- **Right Panel**: Code editor with language selector
- **Run Code**: Tests against visible test cases only
- **Submit**: Tests against all test cases (including hidden)
- **Timer**: Countdown in top-right (turns red when < 5 min)
- **Webcam**: Shows in bottom-right corner (if permitted)

### 3. View Results

After ending the session:
- **Performance Charts**: Doughnut, radar, bar, line graphs
- **Question Breakdown**: Per-question verdict and test cases
- **Behavioral Analysis**: Posture, gaze, and focus scores
- **AI Feedback**: Personalized improvement suggestions

---

## Troubleshooting

### "DATABASE_URL is required" error

Make sure `.env` file exists in the project root with:
```env
DATABASE_URL=postgresql://postgres:postgres@127.0.0.1:5432/app_db
```

### "Connection refused" to PostgreSQL

1. Check PostgreSQL is running:
   ```bash
   # Mac/Linux
   pg_isready
   
   # Windows (in PowerShell)
   Test-NetConnection -ComputerName localhost -Port 5432
   ```

2. Verify credentials in `.env` match your PostgreSQL setup

### "relation does not exist" error

Run the schema push:
```bash
npx drizzle-kit push
```

### Port 3000 already in use

Kill the process or use a different port:
```bash
npm run dev -- -p 3001
```

---

## Extending the Project

### Adding Real AI (Ollama)

1. Install Ollama: https://ollama.com
2. Pull a model: `ollama pull llama3`
3. Update `src/lib/question-generator.ts` to call Ollama API:
   ```typescript
   const response = await fetch('http://localhost:11434/api/generate', {
     method: 'POST',
     body: JSON.stringify({
       model: 'llama3',
       prompt: `Generate coding questions for ${company}...`
     })
   });
   ```

### Adding Real Code Execution (Judge0)

1. Run Judge0 locally with Docker:
   ```bash
   docker-compose -f judge0-docker-compose.yml up -d
   ```
2. Update `src/app/api/sessions/[uid]/submit/route.ts` to call Judge0 API

### Adding Real Webcam Analysis (MediaPipe)

Install MediaPipe in the client component:
```bash
npm install @mediapipe/face_mesh @mediapipe/pose
```

---

## License

MIT License — feel free to use for learning and projects!
